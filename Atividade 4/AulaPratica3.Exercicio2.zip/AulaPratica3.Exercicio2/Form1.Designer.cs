﻿namespace AulaPratica3.Exercicio2
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.txtValorLadoA = new System.Windows.Forms.TextBox();
            this.txtValorLadoC = new System.Windows.Forms.TextBox();
            this.txtValorLadoB = new System.Windows.Forms.TextBox();
            this.lblValorLadoA = new System.Windows.Forms.Label();
            this.lblValorLadoB = new System.Windows.Forms.Label();
            this.lblValorLadoC = new System.Windows.Forms.Label();
            this.Executar = new System.Windows.Forms.Button();
            this.Sair = new System.Windows.Forms.Button();
            this.picboxTriangulo = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picboxTriangulo)).BeginInit();
            this.SuspendLayout();
            // 
            // txtValorLadoA
            // 
            this.txtValorLadoA.Location = new System.Drawing.Point(133, 20);
            this.txtValorLadoA.Name = "txtValorLadoA";
            this.txtValorLadoA.Size = new System.Drawing.Size(100, 20);
            this.txtValorLadoA.TabIndex = 0;
            this.txtValorLadoA.Validated += new System.EventHandler(this.txtValorLadoA_Validated);
            // 
            // txtValorLadoC
            // 
            this.txtValorLadoC.Location = new System.Drawing.Point(133, 86);
            this.txtValorLadoC.Name = "txtValorLadoC";
            this.txtValorLadoC.Size = new System.Drawing.Size(100, 20);
            this.txtValorLadoC.TabIndex = 1;
            this.txtValorLadoC.Validated += new System.EventHandler(this.txtValorLadoC_Validated);
            // 
            // txtValorLadoB
            // 
            this.txtValorLadoB.Location = new System.Drawing.Point(133, 53);
            this.txtValorLadoB.Name = "txtValorLadoB";
            this.txtValorLadoB.Size = new System.Drawing.Size(100, 20);
            this.txtValorLadoB.TabIndex = 2;
            this.txtValorLadoB.Validated += new System.EventHandler(this.txtValorLadoB_Validated);
            // 
            // lblValorLadoA
            // 
            this.lblValorLadoA.AutoSize = true;
            this.lblValorLadoA.Location = new System.Drawing.Point(41, 23);
            this.lblValorLadoA.Name = "lblValorLadoA";
            this.lblValorLadoA.Size = new System.Drawing.Size(68, 13);
            this.lblValorLadoA.TabIndex = 3;
            this.lblValorLadoA.Text = "Valor Lado A";
            // 
            // lblValorLadoB
            // 
            this.lblValorLadoB.AutoSize = true;
            this.lblValorLadoB.Location = new System.Drawing.Point(41, 56);
            this.lblValorLadoB.Name = "lblValorLadoB";
            this.lblValorLadoB.Size = new System.Drawing.Size(68, 13);
            this.lblValorLadoB.TabIndex = 4;
            this.lblValorLadoB.Text = "Valor Lado B";
            // 
            // lblValorLadoC
            // 
            this.lblValorLadoC.AutoSize = true;
            this.lblValorLadoC.Location = new System.Drawing.Point(41, 89);
            this.lblValorLadoC.Name = "lblValorLadoC";
            this.lblValorLadoC.Size = new System.Drawing.Size(68, 13);
            this.lblValorLadoC.TabIndex = 5;
            this.lblValorLadoC.Text = "Valor Lado C";
            // 
            // Executar
            // 
            this.Executar.Location = new System.Drawing.Point(177, 216);
            this.Executar.Name = "Executar";
            this.Executar.Size = new System.Drawing.Size(75, 23);
            this.Executar.TabIndex = 6;
            this.Executar.Text = "Executar";
            this.Executar.UseVisualStyleBackColor = true;
            this.Executar.Click += new System.EventHandler(this.Executar_Click);
            this.Executar.Validated += new System.EventHandler(this.Executar_Validated);
            // 
            // Sair
            // 
            this.Sair.Location = new System.Drawing.Point(80, 216);
            this.Sair.Name = "Sair";
            this.Sair.Size = new System.Drawing.Size(75, 23);
            this.Sair.TabIndex = 7;
            this.Sair.Text = "Sair";
            this.Sair.UseVisualStyleBackColor = true;
            // 
            // picboxTriangulo
            // 
            this.picboxTriangulo.Image = ((System.Drawing.Image)(resources.GetObject("picboxTriangulo.Image")));
            this.picboxTriangulo.Location = new System.Drawing.Point(481, 12);
            this.picboxTriangulo.Name = "picboxTriangulo";
            this.picboxTriangulo.Size = new System.Drawing.Size(293, 260);
            this.picboxTriangulo.TabIndex = 8;
            this.picboxTriangulo.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 289);
            this.Controls.Add(this.picboxTriangulo);
            this.Controls.Add(this.Sair);
            this.Controls.Add(this.Executar);
            this.Controls.Add(this.lblValorLadoC);
            this.Controls.Add(this.lblValorLadoB);
            this.Controls.Add(this.lblValorLadoA);
            this.Controls.Add(this.txtValorLadoB);
            this.Controls.Add(this.txtValorLadoC);
            this.Controls.Add(this.txtValorLadoA);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.picboxTriangulo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtValorLadoA;
        private System.Windows.Forms.TextBox txtValorLadoC;
        private System.Windows.Forms.TextBox txtValorLadoB;
        private System.Windows.Forms.Label lblValorLadoA;
        private System.Windows.Forms.Label lblValorLadoB;
        private System.Windows.Forms.Label lblValorLadoC;
        private System.Windows.Forms.Button Executar;
        private System.Windows.Forms.Button Sair;
        private System.Windows.Forms.PictureBox picboxTriangulo;
    }
}

