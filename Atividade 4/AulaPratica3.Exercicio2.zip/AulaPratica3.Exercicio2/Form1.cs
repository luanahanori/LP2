﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AulaPratica3.Exercicio2
{
    public partial class Form1 : Form
    {
        float LadoA, LadoB, LadoC;
        public Form1()
        {
            InitializeComponent();
            
        }

        private void txtValorLadoA_Validated(object sender, EventArgs e)
        {
                if (!float.TryParse(txtValorLadoA.Text, out LadoA)) 
            {
                MessageBox.Show("Verifique o número digitado no Lado A!");
            }
        }

        private void txtValorLadoB_Validated(object sender, EventArgs e)
        {
                if (!float.TryParse(txtValorLadoB.Text, out LadoB))
            {
                MessageBox.Show("Verifique o número digitado no Lado B!");
            }
        }

        private void Executar_Click(object sender, EventArgs e)
        {
            if (LadoA != 0 && LadoB != 0 && LadoC != 0)
            {
                if (LadoA < (LadoB + LadoC) && LadoB < (LadoA + LadoC) && LadoC < (LadoA + LadoC))
                {
                    if ((LadoA == LadoB && LadoC != LadoA) ^ (LadoB == LadoC && LadoC != LadoA) ^ (LadoA == LadoC && LadoC != LadoB))
                    {
                        MessageBox.Show("Triângulo Isóceles");
                    }
                    if (LadoA != LadoB && LadoB != LadoC && LadoA != LadoC)
                    {
                        MessageBox.Show("Triângulo Escaleno");
                    }
                    if (LadoA == LadoB && LadoB == LadoC && LadoA == LadoC)
                    {
                        MessageBox.Show("Triângulo Equilátero");
                    }
                }
                else
                {
                    MessageBox.Show("Não é um trângulo!");
                }
            }
            else
            {
                MessageBox.Show("Os lados precisam ser diferentes de 0!");
            }
        }

        private void txtValorLadoC_Validated(object sender, EventArgs e)
        {
                if (!float.TryParse(txtValorLadoC.Text, out LadoC))
            {
                MessageBox.Show("Verifique o número digitado no Lado C!");
            }
        }

        private void Executar_Validated(object sender, EventArgs e)
        {
            

        }
    }
}
