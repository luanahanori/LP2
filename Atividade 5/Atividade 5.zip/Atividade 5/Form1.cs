﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_5
{
    public partial class Form1 : Form
    {
        String NomeFunc;
        double SalBruto, SalLiquido, AliqINSS, AliqIRPF, SalFamilia;
        int QtdFilhos;

        private void btnVerificaDesc_Click(object sender, EventArgs e)
        {
            QtdFilhos = (int)nupNumFilhos.Value;
            SalLiquido = SalBruto;

            if (SalBruto >0)
            {

                if (SalBruto <= 800.47)
                {
                    AliqINSS = (7.65 / 100);
                    SalLiquido = SalLiquido - (SalBruto*AliqINSS);
                    txtAliqINSS.Text = "7.65%";
                    txtDescINSS.Text = SalBruto * AliqINSS + "";
                }
                else
                    if (SalBruto <= 1050)
                {
                    AliqINSS = (8.65 / 100);
                    SalLiquido = SalLiquido - (SalBruto * AliqINSS);
                    txtAliqINSS.Text = "8.65%";
                    txtDescINSS.Text = SalBruto * AliqINSS + "";
                }
                else
                    if (SalBruto <= 1400.77)
                {
                    AliqINSS = (9.00 / 100);
                    SalLiquido = SalLiquido - (SalBruto * AliqINSS);
                    txtAliqINSS.Text = "9%";
                    txtDescINSS.Text = SalBruto * AliqINSS + "";
                }
                else
                    if (SalBruto <= 2801.56)
                {
                    AliqINSS = (11.00 / 100);
                    SalLiquido = SalLiquido - (SalBruto * AliqINSS);
                    txtAliqINSS.Text = "11%";
                    txtDescINSS.Text = SalBruto * AliqINSS + "";
                }
                else
                {
                    AliqINSS = 308.17;
                    SalLiquido = (SalBruto - 308.17);
                    txtSalLiquido.Text = SalLiquido + "%";
                    txtDescINSS.Text = "308.17";
                }

                if (SalBruto <= 1257.12)
                {
                    AliqIRPF = 0;
                    SalLiquido = SalLiquido - (SalBruto * AliqIRPF);
                    txtAliqIRPF.Text = "0%";
                    txtDescIRPF.Text = SalBruto * AliqIRPF + "";
                }
                else
                    if (SalBruto <= 2512.08)
                {
                    AliqIRPF = 15.00 / 100;
                    SalLiquido = SalLiquido - (SalBruto * AliqIRPF);
                    txtAliqIRPF.Text = "15%";
                    txtDescIRPF.Text = SalBruto * AliqIRPF + "";
                }
                else
                {
                    SalLiquido = SalLiquido - (SalBruto * (27.5 / 100));
                    AliqIRPF = (SalBruto * (27.5 / 100));
                    txtAliqIRPF.Text = "27.5%";
                    txtDescIRPF.Text = SalBruto * 0.275 + "";
                }

                if ( SalBruto <= 435.52)
                {
                    SalFamilia = 22.33 * QtdFilhos;
                }
                else
                    if (SalBruto <= 654.61)
                {
                    SalFamilia = 15.74 * QtdFilhos;
                }
                else
                {
                    SalFamilia = 0;
                }
                SalLiquido += SalFamilia;
                txtSalFamilia.Text = SalFamilia.ToString();
                txtSalLiquido.Text = SalLiquido.ToString();
                txtAliqINSS.Text = AliqINSS.ToString();

            }
            else
            {
                MessageBox.Show("O valor do Salário bruto deve ser diferente de 0");
            }
        }

        private void mskSalBruto_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskSalBruto.Text, out SalBruto))
            {
                MessageBox.Show("Salário Inválido");
            }
        }

        int NumFilhos;
        public Form1()
        {
            InitializeComponent();
        }

        private void mskNomeFunc_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsNumber(e.KeyChar) || Char.IsPunctuation(e.KeyChar))
                    {
                MessageBox.Show("Caracter Inválido");
                SendKeys.Send("{BACKSPACE}");
            }
        }
    }
}
