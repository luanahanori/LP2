﻿namespace PClasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInstanciarMensalista = new System.Windows.Forms.Button();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtSalarioMensal = new System.Windows.Forms.TextBox();
            this.txtDataEntradaEmpresa = new System.Windows.Forms.TextBox();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalarioMensal = new System.Windows.Forms.Label();
            this.lblDataEntradaEmpresa = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.btnInstanciarPP = new System.Windows.Forms.Button();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnInstanciarMensalista
            // 
            this.btnInstanciarMensalista.Location = new System.Drawing.Point(124, 180);
            this.btnInstanciarMensalista.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnInstanciarMensalista.Name = "btnInstanciarMensalista";
            this.btnInstanciarMensalista.Size = new System.Drawing.Size(139, 51);
            this.btnInstanciarMensalista.TabIndex = 19;
            this.btnInstanciarMensalista.Text = "Instanciar Horista";
            this.btnInstanciarMensalista.UseVisualStyleBackColor = true;
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(188, 21);
            this.txtMatricula.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(68, 20);
            this.txtMatricula.TabIndex = 18;
            // 
            // txtSalarioMensal
            // 
            this.txtSalarioMensal.Location = new System.Drawing.Point(188, 76);
            this.txtSalarioMensal.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtSalarioMensal.Name = "txtSalarioMensal";
            this.txtSalarioMensal.Size = new System.Drawing.Size(89, 20);
            this.txtSalarioMensal.TabIndex = 17;
            // 
            // txtDataEntradaEmpresa
            // 
            this.txtDataEntradaEmpresa.Location = new System.Drawing.Point(188, 103);
            this.txtDataEntradaEmpresa.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtDataEntradaEmpresa.Name = "txtDataEntradaEmpresa";
            this.txtDataEntradaEmpresa.Size = new System.Drawing.Size(89, 20);
            this.txtDataEntradaEmpresa.TabIndex = 16;
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(27, 53);
            this.lblNome.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(35, 13);
            this.lblNome.TabIndex = 15;
            this.lblNome.Text = "Nome";
            // 
            // lblSalarioMensal
            // 
            this.lblSalarioMensal.AutoSize = true;
            this.lblSalarioMensal.Location = new System.Drawing.Point(27, 80);
            this.lblSalarioMensal.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSalarioMensal.Name = "lblSalarioMensal";
            this.lblSalarioMensal.Size = new System.Drawing.Size(76, 13);
            this.lblSalarioMensal.TabIndex = 14;
            this.lblSalarioMensal.Text = "Salário Mensal";
            // 
            // lblDataEntradaEmpresa
            // 
            this.lblDataEntradaEmpresa.AutoSize = true;
            this.lblDataEntradaEmpresa.Location = new System.Drawing.Point(27, 107);
            this.lblDataEntradaEmpresa.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDataEntradaEmpresa.Name = "lblDataEntradaEmpresa";
            this.lblDataEntradaEmpresa.Size = new System.Drawing.Size(144, 13);
            this.lblDataEntradaEmpresa.TabIndex = 13;
            this.lblDataEntradaEmpresa.Text = "Data de Entrada na Empresa";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(188, 49);
            this.txtNome.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(235, 20);
            this.txtNome.TabIndex = 12;
            // 
            // btnInstanciarPP
            // 
            this.btnInstanciarPP.Location = new System.Drawing.Point(282, 180);
            this.btnInstanciarPP.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnInstanciarPP.Name = "btnInstanciarPP";
            this.btnInstanciarPP.Size = new System.Drawing.Size(139, 51);
            this.btnInstanciarPP.TabIndex = 11;
            this.btnInstanciarPP.Text = "Instanciar Horista passando parâmetros";
            this.btnInstanciarPP.UseVisualStyleBackColor = true;
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Location = new System.Drawing.Point(27, 25);
            this.lblMatricula.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(50, 13);
            this.lblMatricula.TabIndex = 10;
            this.lblMatricula.Text = "Matricula";
            // 
            // frmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(533, 292);
            this.Controls.Add(this.btnInstanciarMensalista);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.txtSalarioMensal);
            this.Controls.Add(this.txtDataEntradaEmpresa);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblSalarioMensal);
            this.Controls.Add(this.lblDataEntradaEmpresa);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.btnInstanciarPP);
            this.Controls.Add(this.lblMatricula);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmHorista";
            this.Text = "frmHorista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnInstanciarMensalista;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtSalarioMensal;
        private System.Windows.Forms.TextBox txtDataEntradaEmpresa;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalarioMensal;
        private System.Windows.Forms.Label lblDataEntradaEmpresa;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Button btnInstanciarPP;
        private System.Windows.Forms.Label lblMatricula;
    }
}