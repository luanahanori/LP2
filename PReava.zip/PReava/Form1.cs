﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PReava
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lbMatriz.Items.Clear();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            int[] matriza = new int[5] { 1, 2, 3, 4, 5};
            int[] matrizb = new int[5];

            if ((matriza[0] / 2) == 0)
            {
                matrizb[0] = matriza[0] + 7;
            }
            else
            {
                matrizb[0] = matriza[0] * 7;
            }

            if ((matriza[1] / 2) == 0)
            {
                matrizb[1] = matriza[1] + 7;
            }
            else
            {
                matrizb[1] = matriza[1] * 7;
            }

            if ((matriza[2] / 2) == 0)
            {
                matrizb[2] = matriza[2] + 7;
            }
            else
            {
                matrizb[2] = matriza[2] * 7;
            }
            if ((matriza[0] / 2) == 0)
            {
                matrizb[3] = matriza[3] + 7;
            }
            else
            {
                matrizb[3] = matriza[3] * 7;
            }
            if ((matriza[0] / 2) == 0)
            {
                matrizb[4] = matriza[4] + 7;
            }
            else
            {
                matrizb[4] = matriza[4] * 7;
            }



            lbMatriz.Items.Add($"Posição 0 Matriz A: {matriza[0].ToString()}," +
                $"MatrizB: {matrizb[0].ToString()}");
            lbMatriz.Items.Add($"Posição 1 Matriz A: {matriza[1].ToString()}," +
                $"MatrizB: {matrizb[1].ToString()}");
            lbMatriz.Items.Add($"Posição 2 Matriz A: {matriza[2].ToString()}," +
                $"MatrizB: {matrizb[2].ToString()}");
            lbMatriz.Items.Add($"Posição 3 Matriz A: {matriza[3].ToString()}," +
                $"MatrizB: {matrizb[3].ToString()}");
            lbMatriz.Items.Add($"Posição 4 Matriz A: {matriza[4].ToString()}," +
                $"MatrizB: {matrizb[4].ToString()}");

            






        }
    }
}


            